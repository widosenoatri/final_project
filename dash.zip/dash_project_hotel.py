import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import numpy as np
import pandas as pd
import seaborn as sns
from dash.dependencies import Input, Output, State
import pickle
import numpy as np
import dash_table

def generate_table(dataframe, page_size=10):
    return dash_table.DataTable(
        id='dataTable',
        columns=[{
            "name": i,
            "id": i
        } for i in dataframe.columns],
        data=dataframe.to_dict('records'),
        page_action="native",
        page_current=0,
        page_size=page_size,
        style_table={'minWidth': '0px',
            'maxHeight': '500px',
            'overflowY': 'scroll',
            'overflowX': 'scroll'},
        style_cell={'minWidth': '0px',
            'maxWidth': '180px',
            'overflow': 'hidden',
            'textOverflow': 'ellipsis',
            'height':'auto'}
        )



df = pd.read_csv('hotel_bookings.csv')
df['arrival_date_year'] = df['arrival_date_year'].astype('str')


external_stylesheets = ["https://codepen.io/chriddyp/pen/bWLwgP.css"]

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
loadModel = pickle.load(open('hotel_bookings_xgb.sav', 'rb'))

app.layout = html.Div(children=[
    html.Center(html.H1('Hotel Bookings')),
    html.Div(children='by: Widoseno N. S. Atri'),

    dcc.Tabs(value = 'Tab', id='tab_besar', children=[

#######################################Tab 1#######################################
        dcc.Tab(value = 'Tab1', label = 'DataFrame Table', children =[
                html.Center(html.H2('Dataframe Hotel Bookings')),
                html.Div(children =[
                    html.Div(children =[
                        html.P('Hotel Type:'),
                        dcc.Dropdown(value = 'None', id='filter-hotel', 
                            options = [{'label':'City Hotel', 'value': 'City Hotel'},
                                    {'label':'Resort Hotel', 'value': 'Resort Hotel'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3'),# Hotel
                    

                    html.Div(children =[
                        html.P('Arrival Year:'),
                        dcc.Dropdown(value = 'None', id='filter-year', 
                            options = [{'label':'2015', 'value': '2015'},
                                    {'label':'2016', 'value': '2016'},
                                    {'label':'2017', 'value': '2017'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3'),# Year


                    html.Div(children =[
                        html.P('Arrival Month:'),
                        dcc.Dropdown(value = 'None', id='filter-month', 
                            options = [{'label':'January', 'value': 'January'},
                                    {'label':'February', 'value': 'February'},
                                    {'label':'March', 'value': 'March'},
                                    {'label':'April', 'value': 'April'},
                                    {'label':'May', 'value': 'May'},
                                    {'label':'June', 'value': 'June'},
                                    {'label':'July', 'value': 'July'},
                                    {'label':'August', 'value': 'August'},
                                    {'label':'September', 'value': 'September'},
                                    {'label':'October', 'value': 'October'},
                                    {'label':'November', 'value': 'November'},
                                    {'label':'December', 'value': 'December'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3'),# Arrival Month

                    html.Div(children =[
                        html.P('Meal:'),
                        dcc.Dropdown(value = 'None', id='filter-meal', 
                            options = [{'label':'Bed & Breakfast', 'value': 'BB'},
                                    {'label':'Half Board', 'value': 'HB'},
                                    {'label':'Full Board', 'value': 'FB'},
                                    {'label':'No Meal Package(SC)', 'value': 'SC'},
                                    {'label':'No Meal Package(Undefined)', 'value': 'Undefined'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3')# Meal

                ], className = 'row'),# 1-row : hotel, year, month, meal
                

                html.Div(children =[
                    html.Div(children =[
                        html.P('Market Segment:'),
                        dcc.Dropdown(value = 'None', id='filter-market', 
                            options = [{'label':'Online TA', 'value': 'Online TA'},
                                    {'label':'Offline TA/TO', 'value': 'Offline TA/TO'},
                                    {'label':'Groups', 'value': 'Groups'},
                                    {'label':'Direct', 'value': 'Direct'},
                                    {'label':'Corporate', 'value': 'Corporate'},
                                    {'label':'Complementary', 'value': 'Complementary'},
                                    {'label':'Aviation', 'value': 'Aviation'},
                                    {'label':'Undefined', 'value': 'Undefined'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3'),# Market Segment

                    html.Div(children =[
                        html.P('Distribution Channel:'),
                        dcc.Dropdown(value = 'None', id='filter-distribution', 
                            options = [{'label':'TA/TO', 'value': 'TA/TO'},
                                    {'label':'Direct', 'value': 'Direct'},
                                    {'label':'Corporate', 'value': 'Corporate'},
                                    {'label':'GDS', 'value': 'GDS'},
                                    {'label':'Undefined', 'value': 'Undefined'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3'),# Distribution Channel

                    html.Div(children =[
                        html.P('Deposit Type:'),
                        dcc.Dropdown(value = 'None', id='filter-deposit', 
                            options = [{'label':'No Deposit', 'value': 'No Deposit'},
                                    {'label':'Non Refund', 'value': 'Non Refund'},
                                    {'label':'Refundable', 'value': 'Refundable'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3'),# Deposit Type

                    html.Div(children =[
                        html.P('Customer Type:'),
                        dcc.Dropdown(value = 'None', id='filter-customer', 
                            options = [{'label':'Transient', 'value': 'Transient'},
                                    {'label':'Transient-Party', 'value': 'Transient-Party'},
                                    {'label':'Contract', 'value': 'Contract'},
                                    {'label':'Group', 'value': 'Group'},
                                    {'label':'None', 'value':'None'}])
                    ], className = 'col-3'),# Customer Type

                ], className = 'row'),# 1-row : market, distribution, deposit, customer

                html.Br(),
                html.Div([
                    html.P('Max Rows : '),
                    dcc.Input(
                        id='filter-row',
                        type='number',
                        value=10,
                    )
                ], className = 'row col-3'),
                html.Br(),
                html.Div(children =[
                        html.Button('search',id = 'filter')
                    ],className = 'col-4'),
                html.Br(),    
                html.Div(id = 'div-table', children =[generate_table(df)
            ])
            ]),#Tab1

#######################################Tab 2#######################################
        dcc.Tab(value='Tab2', label='EDA',children=[
            html.Div([
                html.Div(
                        dcc.Dropdown(id ='pie-dropdown', 
                        options = [{'label': i, 'value': i} for i in df.select_dtypes('object').columns], 
                        value = 'hotel'
                ), className = 'col-3'),

                html.Div([
                    dcc.Graph(
                    id = 'pie-graph',
                    figure ={
                        'data' : [
                        go.Pie(labels=[(df[i].value_counts().index) for i in df.select_dtypes('object').columns], 
                            values=[(df[j].value_counts().values) for j in df.select_dtypes('object').columns],
                            sort = False)
                        ], 
                        'layout': {'title' : 'Data Percentage'}}
                    )#dccGraph
                ])
            ]),#Div-Pie

            html.Div([
                html.Div(
                        dcc.Dropdown(id ='bar-dropdown', 
                        options = [{'label': 'Hotel Type', 'value': 'hotel'},
                                    {'label': 'Arrival Year', 'value': 'arrival_date_year'},
                                    {'label': 'Arrival Month', 'value': 'arrival_date_month'},
                                    {'label': 'Meal', 'value': 'meal'},
                                    {'label': 'Market Segment', 'value': 'market_segment'},
                                    {'label': 'Distribution Channel', 'value': 'distribution_channel'},
                                    {'label': 'Deposit Type', 'value': 'deposit_type'},
                                    {'label': 'Customer Type', 'value': 'customer_type'},
                        ], 
                        value = 'hotel'
                ), className = 'col-3'),

                html.Div([
                    dcc.Graph(
                        id = 'graph-bar',
                        figure ={
                            'data' : [
                                {'x': list(pd.DataFrame(df.groupby('is_canceled')['deposit_type'].value_counts()).loc[0]['deposit_type'].index), 
                                    'y': list(pd.DataFrame(df.groupby('is_canceled')['deposit_type'].value_counts()).loc[0]['deposit_type'].values), 
                                    'type': 'bar', 'name' :'Not Canceled'},
                                {'x': list(pd.DataFrame(df.groupby('is_canceled')['deposit_type'].value_counts()).loc[1]['deposit_type'].index), 
                                    'y': list(pd.DataFrame(df.groupby('is_canceled')['deposit_type'].value_counts()).loc[0]['deposit_type'].values), 
                                    'type': 'bar', 'name': 'Canceled'}
                            ], 
                            'layout': {'title': 'Comparison between Canceled and Not Canceled'}  
                        }
                    )
                ])
            ])# Div-Bar
        ]),#Tab2


#######################################Tab 3#######################################
        dcc.Tab(value='Tab3', label='Machine Learning',children=[
            html.Div([
                html.Div(children=[
                    html.P('Reason: '),
                    dcc.Dropdown(id='my-id-hotel', value = 'City Hotel',
                    options= [{'label' : 'Resort Hotel', 'value' : 'Resort Hotel'},
                            {'label' : 'City Hotel', 'value' : 'City Hotel'}])
                ], className='col-3'),

                html.Div(children=[
                    html.P('Arrival Month: '),
                    dcc.Dropdown(id='my-id-month', value = 'February',
                    options= [{'label':'January', 'value': 'January'},
                                    {'label':'February', 'value': 'February'},
                                    {'label':'March', 'value': 'March'},
                                    {'label':'April', 'value': 'April'},
                                    {'label':'May', 'value': 'May'},
                                    {'label':'June', 'value': 'June'},
                                    {'label':'July', 'value': 'July'},
                                    {'label':'August', 'value': 'August'},
                                    {'label':'September', 'value': 'September'},
                                    {'label':'October', 'value': 'October'},
                                    {'label':'November', 'value': 'November'},
                                    {'label':'December', 'value': 'December'}]),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Meal: '),
                    dcc.Dropdown(id='my-id-meal', value = 'BB',
                    options= [{'label':'FB', 'value': 'FB'},
                                    {'label':'BB', 'value': 'BB'},
                                    {'label':'HB', 'value': 'HB'},
                                    {'label':'SC/Undefined', 'value': 'SC'}]),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Citizen(POR): '),
                    dcc.Dropdown(id='my-id-citizen', value = 'citizen',
                    options= [{'label':'Citizen', 'value': 'citizen'},
                                    {'label':'Not Citizen', 'value': 'not citizen'}]),
                ], className='col-3'),
            ], className='row'),

            
            html.Br(),
            html.Div([
                html.Div(children=[
                    html.P('Market Segment: '),
                    dcc.Dropdown(id='my-id-market', value = 'Offline TA/TO',
                    options= [{'label' : 'Online TA', 'value' : 'Online TA'},
                            {'label' : 'Offline TA/TO', 'value' : 'Offline TA/TO'},
                            {'label' : 'Groups', 'value' : 'Groups'},
                            {'label' : 'Direct', 'value' : 'Direct'},
                            {'label' : 'Corporate', 'value' : 'Corporate'},
                            {'label' : 'Complementary', 'value' : 'Complementary'},
                            {'label' : 'Aviation', 'value' : 'Aviation'},
                            {'label' : 'Undefined', 'value' : 'Undefined'}])
                ], className='col-3'),

                html.Div(children=[
                    html.P('Distribution Channel: '),
                    dcc.Dropdown(id='my-id-distribution', value = 'TA/TO',
                    options= [{'label' : 'TA/TO', 'value' : 'TA/TO'},
                            {'label' : 'Direct', 'value' : 'Direct'},
                            {'label' : 'Corporate', 'value' : 'Corporate'},
                            {'label' : 'GDS', 'value' : 'GDS'},
                            {'label' : 'Undefined', 'value' : 'Undefined'}]),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Reserved Room Type: '),
                    dcc.Dropdown(id='my-id-reserved', value = 'A',
                    options= [{'label':'A', 'value': 'A'},
                            {'label':'B', 'value': 'B'},
                            {'label':'C', 'value': 'C'},
                            {'label':'D', 'value': 'D'},
                            {'label':'E', 'value': 'E'},
                            {'label':'F', 'value': 'F'},
                            {'label':'G', 'value': 'G'},
                            {'label':'H', 'value': 'H'},
                            {'label':'P', 'value': 'P'},
                            {'label':'L', 'value': 'L'}]),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Assigned Room Type: '),
                    dcc.Dropdown(id='my-id-assigned', value = 'A',
                    options= [{'label':'A', 'value': 'A'},
                            {'label':'B', 'value': 'B'},
                            {'label':'C', 'value': 'C'},
                            {'label':'D', 'value': 'D'},
                            {'label':'E', 'value': 'E'},
                            {'label':'F', 'value': 'F'},
                            {'label':'G', 'value': 'G'},
                            {'label':'H', 'value': 'H'},
                            {'label':'I', 'value': 'I'},
                            {'label':'K', 'value': 'K'},
                            {'label':'P', 'value': 'P'},
                            {'label':'L', 'value': 'L'}]),
                ], className='col-3'),
            ], className='row'),

            html.Br(),
            html.Div([
                html.Div(children=[
                    html.P('Deposit Type: '),
                    dcc.Dropdown(id='my-id-deposit', value = 'Non Refund',
                    options= [{'label' : 'No Deposit', 'value' : 'No Deposit'},
                            {'label' : 'Non Refund', 'value' : 'Non Refund'},
                            {'label' : 'Refundable', 'value' : 'Refundable'}])
                ], className='col-3'),

                html.Div(children=[
                    html.P('Customer Type: '),
                    dcc.Dropdown(id='my-id-customer', value = 'Transient',
                    options= [{'label' : 'Transient', 'value' : 'Transient'},
                            {'label' : 'Transient-Party', 'value' : 'Transient-Party'},
                            {'label' : 'Contract', 'value' : 'Contract'},
                            {'label' : 'Group', 'value' : 'Group'}]),
                ], className='col-3')
            ], className='row'),


            html.Br(),
            html.Div([
                html.Div([
                    html.P('Lead Time: '),
                    dcc.Input(id='my-id-lead', value = '44', type = 'number')
                ], className='col-3'),

                html.Div(children=[
                    html.P('Year: '),
                    dcc.Input(id='my-id-year', value = '2016', type = 'number')
                ], className='col-3'),

                html.Div(children=[
                    html.P('Week Number: '),
                    dcc.Input(id='my-id-week', value = '8', type = 'number')
                ], className='col-3'),

                html.Div(children=[
                    html.P('Date of the Month: '),
                    dcc.Input(id='my-id-date', value = '17', type = 'number'),
                ], className='col-3')
            ], className='row'),

            html.Br(),
            html.Div([
                html.Div(children=[
                    html.P('Stays in weekend nights: '),
                    dcc.Input(id='my-id-weekendnights', value = '0', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Stays in week nights: '),
                    dcc.Input(id='my-id-weeknights', value = '3', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Adults: '),
                    dcc.Input(id='my-id-adults', value = '2', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Children: '),
                    dcc.Input(id='my-id-children', value = '0', type = 'number'),
                ], className='col-3')
            ], className='row'),


            html.Br(),
            html.Div([
                html.Div(children=[
                    html.P('Babies: '),
                    dcc.Input(id='my-id-babies', value = '0', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Repeated Guest: '),
                    dcc.Input(id='my-id-repeatedguest', value = '0', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Previous Cancellation: '),
                    dcc.Input(id='my-id-previous', value = '0', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Previous Bookings Not Cancelled: '),
                    dcc.Input(id='my-id-previousbook', value = '0', type = 'number'),
                ], className='col-3')
            ], className='row'),


            html.Br(),
            html.Div([
                html.Div(children=[
                    html.P('Booking Changes: '),
                    dcc.Input(id='my-id-booking', value = '0', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Days in Waiting List: '),
                    dcc.Input(id='my-id-waitinglist', value = '3', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Average Daily Rate: '),
                    dcc.Input(id='my-id-adr', value = '75', type = 'number'),
                ], className='col-3'),

                html.Div(children=[
                    html.P('Car Parking Spaces: '),
                    dcc.Input(id='my-id-carpark', value = '0', type = 'number'),
                ], className='col-3')
            ], className='row'),


            html.Br(),
            html.Div([
                html.Div(children=[
                    html.P('Total Number of Special Requests: '),
                    dcc.Input(id='my-id-specialrequest', value = '0', type = 'number'),
                ], className='col-3')
            ], className='row'),

            html.Br(),
            html.Div(children =[
                    html.Button('Predict',id = 'prediksi')
            ],className = 'col-4'),
        
            html.Br(),
            html.Div(id = 'my-div')
        ])#dcc.Tab3
        

    ], content_style= {
            'fontFamily': 'Arial',
            'borderBottom': '1px solid #d6d6d6',
            'borderLeft': '1px solid #d6d6d6',
            'borderRight': '1px solid #d6d6d6',
            'padding': '44px'
        }
    )#dcc.Tabs
      
    ]#children(app_layout)
)#app_layout



#######################################Dataframe#######################################
@app.callback(
    Output(component_id = 'div-table', component_property = 'children'),
    [Input('filter', 'n_clicks')],
    [State('filter-hotel', 'value'),
    State('filter-year', 'value'),
    State('filter-month', 'value'),
    State('filter-meal', 'value'),
    State('filter-market', 'value'),
    State('filter-distribution', 'value'),
    State('filter-deposit', 'value'),
    State('filter-customer', 'value'),
    State('filter-row', 'value')
    ]
)

def update_table(n_clicks, hotel, year, month, meal, market, distribution, deposit, customer, row):
    df = pd.read_csv('hotel_bookings.csv')
    df['arrival_date_year'] = df['arrival_date_year'].astype('str')

    if hotel != 'None':
        df = df[df['hotel'] == hotel]
    if year != 'None':
        df = df[df['arrival_date_year'] == year]
    if month != 'None':
        df = df[df['arrival_date_month'] == month]
    if meal != 'None':
        df = df[df['meal'] == meal]
    if market != 'None':
        df = df[df['market_segment'] == market]
    if distribution != 'None':
        df = df[df['distribution_channel'] == distribution]
    if deposit != 'None':
        df = df[df['deposit_type'] == deposit]
    if customer != 'None':
        df = df[df['customer_type'] == customer]
    
    
    if (hotel=='None') and (year=='None') and (month=='None') and (meal=='None') and (market=='None') and (distribution=='None') and (deposit=='None') and (customer=='None'):
        df = df = pd.read_csv('hotel_bookings.csv')
        df['arrival_date_year'] = df['arrival_date_year'].astype('str')
    

    children = [generate_table(df, page_size = row)]
    return children



#######################################Pie Graph#######################################
@app.callback(
    Output(component_id = 'pie-graph', component_property = 'figure'),
    [Input('pie-dropdown', 'value')]
)
def create_graph_pie(x):
    df = pd.read_csv('hotel_bookings.csv')
    df['arrival_date_year'] = df['arrival_date_year'].astype('str')
    df['arrival_date_week_number'] = df['arrival_date_week_number'].astype('str')
    df['arrival_date_day_of_month'] = df['arrival_date_day_of_month'].astype('str')
    df['is_repeated_guest'] = df['is_repeated_guest'].astype('str')
    df['agent'] = df['agent'].astype('str')
    df['company'] = df['company'].astype('str')

    figure = {
                'data' : [
                    go.Pie(labels=(df[x].value_counts().index), 
                        values=(df[x].value_counts().values),
                        sort = False)
                ], 
                'layout': {'title': 'Data Percentage'}}

    return figure


#######################################Bar Graph#######################################
@app.callback(
    Output(component_id = 'graph-bar', component_property = 'figure'),
    [Input('bar-dropdown', 'value')]
)

def create_graph_bar(x):
    figure = {
        'data' : [
            {'x': list(pd.DataFrame(df.groupby('is_canceled')[x].value_counts()).loc[0][x].index), 
                'y': list(pd.DataFrame(df.groupby('is_canceled')[x].value_counts()).loc[0][x].values), 
                'type': 'bar', 'name' : 'Not Canceled'},
            {'x': list(pd.DataFrame(df.groupby('is_canceled')[x].value_counts()).loc[1][x].index), 
            'y': list(pd.DataFrame(df.groupby('is_canceled')[x].value_counts()).loc[1][x].values), 
            'type': 'bar', 'name': 'Canceled'}
        ], 
        'layout': {'title': 'Comparison between Canceled and Not Canceled'}  
        }

    return figure 



#######################################Machine Learning#######################################
@app.callback(
    Output(component_id = 'my-div', component_property = 'children'),
    [Input('prediksi', 'n_clicks')],
    [State('my-id-hotel', 'value'),
    State('my-id-month', 'value'),
    State('my-id-meal', 'value'),
    State('my-id-citizen', 'value'),
    State('my-id-market', 'value'),
    State('my-id-distribution', 'value'),
    State('my-id-reserved', 'value'),
    State('my-id-assigned', 'value'),
    State('my-id-deposit', 'value'),
    State('my-id-customer', 'value'),
    State('my-id-lead', 'value'),
    State('my-id-year', 'value'),
    State('my-id-week', 'value'),
    State('my-id-date', 'value'),
    State('my-id-weekendnights', 'value'),
    State('my-id-weeknights', 'value'),
    State('my-id-adults', 'value'),
    State('my-id-children', 'value'),
    State('my-id-babies', 'value'),
    State('my-id-repeatedguest', 'value'),
    State('my-id-previous', 'value'),
    State('my-id-previousbook', 'value'),
    State('my-id-booking', 'value'),
    State('my-id-waitinglist', 'value'),
    State('my-id-adr', 'value'),
    State('my-id-carpark', 'value'),
    State('my-id-specialrequest', 'value')
    ]
     
)

    

def update_output_div(n_clicks, hotel, month, meal, citizen, market, distribution, reserved, assigned, deposit, customer,
                        lead, year, week, date, weekendnights, weeknights, adults, children, babies, repeatedguest,
                        previous, previousbook, booking, waitinglist, adr, carpark, specialrequest):

#################################_CATEGORICAL_#################################
    hotel_Resort = 0
    if(hotel == 'Resort Hotel'):
        hotel_Resort = 1

    month_Aug = 0
    month_Dec = 0    
    month_Feb = 0    
    month_Jan = 0     
    month_Jul = 0        
    month_Jun = 0        
    month_Mar = 0       
    month_May = 0
    month_Nov = 0
    month_Oct = 0
    month_Sep = 0
    if(month == 'August'):
        month_Aug = 1
    elif(month == 'December'):
        month_Dec = 1
    elif(month == 'February'):
        month_Feb = 1
    elif(month == 'January'):
        month_Jan = 1
    elif(month == 'July'):
        month_Jul = 1
    elif(month == 'June'):
        month_Jun = 1
    elif(month == 'March'):
        month_Mar = 1
    elif(month == 'May'):
        month_May = 1
    elif(month == 'November'):
        month_Nov = 1
    elif(month == 'October'):
        month_Oct = 1
    elif(month == 'September'):
        month_Sep = 1


    meal_FB = 0
    meal_HB = 0
    meal_SC = 0
    if(meal == 'FB'):
        meal_FB = 1
    elif(meal == 'HB'):
        meal_HB = 1
    elif(meal == 'SC'):
        meal_SC = 1

    citizen_not = 0
    if(citizen == 'not citizen'):
        citizen_not = 1

    market_segment_Complementary = 0
    market_segment_Corporate = 0
    market_segment_Direct = 0
    market_segment_Groups = 0
    market_segment_Offline = 0
    market_segment_Online = 0
    if(market == 'Complementary'):
        market_segment_Complementary = 1
    elif(market == 'Corporate'):
        market_segment_Corporate = 1
    elif(market == 'Direct'):
        market_segment_Direct = 1
    elif(market == 'Groups'):
        market_segment_Groups = 1
    elif(market == 'Offline TA/TO'):
        market_segment_Offline = 1
    elif(market == 'Online TA'):
        market_segment_Online = 1

    distribution_channel_Direct=0
    distribution_channel_GDS=0
    distribution_channel_TA=0
    distribution_channel_Undefined=0
    if(distribution == 'Direct'):
        distribution_channel_Direct = 1
    elif(distribution == 'GDS'):
        distribution_channel_GDS = 1
    elif(distribution == 'TA/TO'):
        distribution_channel_TA = 1
    elif(market == 'Undefined'):
        distribution_channel_Undefined = 1

    reserved_room_type_B = 0
    reserved_room_type_C = 0
    reserved_room_type_D = 0
    reserved_room_type_E = 0
    reserved_room_type_F = 0
    reserved_room_type_G = 0
    reserved_room_type_H = 0
    reserved_room_type_L = 0
    if(reserved == 'B'):
        reserved_room_type_B=1
    elif(reserved == 'C'):
        reserved_room_type_C=1
    elif(reserved == 'D'):
        reserved_room_type_D=1
    elif(reserved == 'E'):
        reserved_room_type_E=1
    elif(reserved == 'F'):
        reserved_room_type_F=1
    elif(reserved == 'G'):
        reserved_room_type_G=1
    elif(reserved == 'H'):
        reserved_room_type_H=1
    elif(reserved == 'L'):
        reserved_room_type_L=1


    assigned_room_type_B = 0
    assigned_room_type_C = 0
    assigned_room_type_D = 0
    assigned_room_type_E = 0
    assigned_room_type_F = 0
    assigned_room_type_G = 0
    assigned_room_type_H = 0
    assigned_room_type_I = 0
    assigned_room_type_K = 0
    assigned_room_type_L = 0
    if(assigned == 'B'):
        assigned_room_type_B=1
    elif(assigned == 'C'):
        assigned_room_type_C=1
    elif(assigned == 'D'):
        assigned_room_type_D=1
    elif(assigned == 'E'):
        assigned_room_type_E=1
    elif(assigned == 'F'):
        assigned_room_type_F=1
    elif(assigned == 'G'):
        assigned_room_type_G=1
    elif(assigned == 'H'):
        assigned_room_type_H=1
    elif(assigned == 'I'):
        assigned_room_type_I=1
    elif(assigned == 'K'):
        assigned_room_type_K=1
    elif(assigned == 'L'):
        assigned_room_type_L=1


    deposit_type_Non = 0
    deposit_type_Refundable = 0
    if(deposit == 'Non Refund'):
        deposit_type_Non = 1
    elif(deposit == 'Refundable'):
        deposit_type_Refundable = 1

    
    customer_type_Group = 0
    customer_type_Transient = 0
    customer_type_Party = 0
    if(customer == 'Group'):
        customer_type_Group = 1
    elif(customer == 'Transient'):
        customer_type_Transient = 1
    elif(customer == 'Transient-Party'):
        customer_type_Party = 1

#################################_NUMERICAL_#################################
    my_lead = float(lead)
    my_year = float(year)
    my_week = float(week)
    my_date = float(date)
    my_weekendnights = float(weekendnights)
    my_weeknights = float(weeknights)
    my_adults = float(adults)
    my_children = float(children)
    my_babies = float(babies)
    my_repeatedguest = float(repeatedguest)
    my_previous = float(previous)
    my_previousbook = float(previousbook)
    my_booking = float(booking)
    my_waitinglist = float(waitinglist)
    my_adr = float(adr)
    my_carpark = float(carpark)
    my_specialrequest = float(specialrequest)

# DataFrame.dtypes for data must be int, float or bool.
# Did not expect the data types in fields lead_time, arrival_date_year, arrival_date_week_number, arrival_date_day_of_month, 
#                                     stays_in_weekend_nights, stays_in_week_nights, adults, children, babies, is_repeated_guest, 
#                                     previous_cancellations, previous_bookings_not_canceled, booking_changes, days_in_waiting_list, 
#                                     adr, required_car_parking_spaces, total_of_special_requests


    data_baru = pd.DataFrame(data = [(my_lead, my_year, my_week, my_date, my_weekendnights, my_weeknights, 
                        my_adults, my_children, my_babies, my_repeatedguest, my_previous, my_previousbook, 
                        my_booking, my_waitinglist, my_adr, my_carpark, my_specialrequest, hotel_Resort,
                        month_Aug, month_Dec, month_Feb, month_Jan, month_Jul, month_Jun, 
                        month_Mar, month_May, month_Nov, month_Oct, month_Sep, 
                        meal_FB, meal_HB, meal_SC, market_segment_Complementary, 
                        market_segment_Corporate, market_segment_Direct, market_segment_Groups, 
                        market_segment_Offline, market_segment_Online, distribution_channel_Direct,
                        distribution_channel_GDS, distribution_channel_TA, distribution_channel_Undefined,
                        reserved_room_type_B, reserved_room_type_C, reserved_room_type_D, reserved_room_type_E,
                        reserved_room_type_F, reserved_room_type_G, reserved_room_type_H, reserved_room_type_L, 
                        assigned_room_type_B, assigned_room_type_C, assigned_room_type_D, assigned_room_type_E,
                        assigned_room_type_F, assigned_room_type_G, assigned_room_type_H, assigned_room_type_I,
                        assigned_room_type_K, assigned_room_type_L, deposit_type_Non, deposit_type_Refundable,
                        customer_type_Group, customer_type_Transient, customer_type_Party, citizen_not)],
            columns = ['lead_time', 'arrival_date_year', 'arrival_date_week_number',
                        'arrival_date_day_of_month', 'stays_in_weekend_nights',
                        'stays_in_week_nights', 'adults', 'children', 'babies',
                        'is_repeated_guest', 'previous_cancellations',
                        'previous_bookings_not_canceled', 'booking_changes',
                        'days_in_waiting_list', 'adr', 'required_car_parking_spaces',
                        'total_of_special_requests', 'hotel_Resort Hotel',
                        'arrival_date_month_August', 'arrival_date_month_December',
                        'arrival_date_month_February', 'arrival_date_month_January',
                        'arrival_date_month_July', 'arrival_date_month_June',
                        'arrival_date_month_March', 'arrival_date_month_May',
                        'arrival_date_month_November', 'arrival_date_month_October',
                        'arrival_date_month_September', 'meal_FB', 'meal_HB', 'meal_SC',
                        'market_segment_Complementary', 'market_segment_Corporate',
                        'market_segment_Direct', 'market_segment_Groups',
                        'market_segment_Offline TA/TO', 'market_segment_Online TA',
                        'distribution_channel_Direct', 'distribution_channel_GDS',
                        'distribution_channel_TA/TO', 'distribution_channel_Undefined',
                        'reserved_room_type_B', 'reserved_room_type_C', 'reserved_room_type_D',
                        'reserved_room_type_E', 'reserved_room_type_F', 'reserved_room_type_G',
                        'reserved_room_type_H', 'reserved_room_type_L', 'assigned_room_type_B',
                        'assigned_room_type_C', 'assigned_room_type_D', 'assigned_room_type_E',
                        'assigned_room_type_F', 'assigned_room_type_G', 'assigned_room_type_H',
                        'assigned_room_type_I', 'assigned_room_type_K', 'assigned_room_type_L',
                        'deposit_type_Non Refund', 'deposit_type_Refundable',
                        'customer_type_Group', 'customer_type_Transient',
                        'customer_type_Transient-Party', 'citizen_not citizen'])

    predict = loadModel.predict(data_baru.values)
    proba = loadModel.predict_proba(data_baru.values)

    a = proba[0][0]
    b = proba[0][1]
    if(str(predict[0]) == '0'):
        return "The Guest will not cancel with the probabilities of " + f'{a:.5f}' + " Percent of NOT Cancelling, and " + f'{b:.5f}' +" Percent of Cancelling"
    elif(str(predict[0]) == '1'):
        return "The Guest will cancel with the probabilities of " + f'{a:.5f}' + " Percent of NOT Cancelling, and " + f'{b:.5f}' + " Percent of Cancelling"


if __name__ == '__main__':
    app.run_server(debug=True)